﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClassLibraryPassword;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryPassword.Tests
{
    [TestClass()]
    public class PasswordCheckerTests
    {
        [TestMethod()]
        public void Check_8Symbols_ReturnTrue()
        {
            // Arrange.
            string password = "ASqw12$$";
            bool expected = true;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);
            // Assert.
            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void Check_4Symbols_ReturnFalse()
        {
            // Arrange.
            string password = "Aq1$";
            

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);
            // Assert.
            Assert.IsFalse(actual);
        }
        [TestMethod()]
        public void Check_30Symbols_ReturnFalse()
        {
            // Arrange.
            string password = "ASDqwe123$ASDqwe123$ASDqwe123$ASDqwe123$";
            bool expected = false;

            // Act.
           bool actual = PasswordChecker.ValidatePassword(password);
            // Assert.
            Assert.IsFalse(actual);
        }
        [TestMethod()]
        public void Check_Nums_ReturnTrue()
        {
            // Arrange.
            string password = "ASDqwe1$";
            bool expected = true;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);
            // Assert.
            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void Check_Nums_ReturnFalse()
        {
            // Arrange.
            string password = "ASDqweASD$";
            bool expected = false;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);
            // Assert.
            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void Check_Symbols_ReturnTrue()
        {
            // Arrange.
            string password = "Aqwe123$";
            bool expected = true;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);
            // Assert.
            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void Check_Symbols_ReturnFalse()
        {
            // Arrange.
            string password = "ASDqwe123";
            bool expected = false;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);
            // Assert.
            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void Check_UppercaseSymbols_ReturnTrue()
        {
            // Arrange.
            string password = "Aqwe123$";
            bool expected = true;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);
            // Assert.
            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void Check_UppercaseSymbols_ReturnFalse()
        {
            // Arrange.
            string password = "asdqwe123$";
            bool expected = false;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);
            // Assert.
            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void Check_LowerSymbols_ReturnTrue()
        {
            // Arrange.
            string password = "ASDq123$";
            bool expected = true;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);
            // Assert.
            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void Check_LowerSymbols_ReturnFalse()
        {
            // Arrange.
            string password = "ASDQWE123$";
            bool expected = false;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);
            // Assert.
            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void Check_CorrectPassword_ReturnTrue()
        {
            // Arrange.
            string password = "ASDqwe123$";
            bool expected = true;

            // Act.
            bool actual = PasswordChecker.ValidatePassword(password);
            // Assert.
            Assert.AreEqual(expected, actual);
        }
    }
}