﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MathQuiz
{
    public partial class Form1 : Form
    {
        // Create a Random object called randomizer 
        // to generate random numbers.
        Random randomizer = new Random();

        // These integer variables store the numbers 
        // for the addition problem. 
        int addend1;
        int addend2;

        // These integer variables store the numbers 
        // for the subtraction problem. 
        int minuend;
        int subtrahend;

        // These integer variables store the numbers 
        // for the multiplication problem. 
        int multiplicand;
        int multiplier;

        // These integer variables store the numbers 
        // for the division problem. 
        int dividend;
        int divisor;
        /// <summary>
        /// Start the quiz by filling in all of the problem 
        /// values and starting the timer. 
        /// </summary>


        public void StartTheQuiz()
        {
            addend1 = randomizer.Next(51);
            addend2 = randomizer.Next(51);
            plusLeftLabel.Text = addend1.ToString();
            plusRightLabel.Text = addend2.ToString();
            sum.Value = 0;
        }
            public partial class Form1 : Form
            {
                // Create a Random object called randomizer 
                // to generate random numbers.
                Random randomizer = new Random();

                // These integer variables store the numbers 
                // for the addition problem. 
                int addend1;
                int addend2;

                // These integer variables store the numbers 
                // for the subtraction problem. 
                int minuend;
                int subtrahend;

                // These integer variables store the numbers 
                // for the multiplication problem. 
                int multiplicand;
                int multiplier;

                // These integer variables store the numbers 
                // for the division problem. 
                int dividend;
                int divisor;
            /// <summary>
            /// Start the quiz by filling in all of the problem 
            /// values and starting the timer. 
            /// </summary>
            int timeLeft;
            public Form1()

            {
                InitializeComponent();
            }

            public void StartTheQuiz()
            {
               
                addend1 = randomizer.Next(51);
                addend2 = randomizer.Next(51);

                
                plusLeftLabel.Text = addend1.ToString();
                plusRightLabel.Text = addend2.ToString();

                
                sum.Value = 0;

                // Fill in the subtraction problem.
                minuend = randomizer.Next(1, 101);
                subtrahend = randomizer.Next(1, minuend);
                minusLeftLabel.Text = minuend.ToString();
                minusRightLabel.Text = subtrahend.ToString();
                difference.Value = 0;

                // Fill in the multiplication problem.
                multiplicand = randomizer.Next(2, 11);
                multiplier = randomizer.Next(2, 11);
                timesLeftLabel.Text = multiplicand.ToString();
                timesRightLabel.Text = multiplier.ToString();
                product.Value = 0;

                // Fill in the division problem.
                divisor = randomizer.Next(2, 11);
                int temporaryQuotient = randomizer.Next(2, 11);
                dividend = divisor * temporaryQuotient;
                dividedLeftLabel.Text = dividend.ToString();
                dividedRightLabel.Text = divisor.ToString();
                quotient.Value = 0;

                private void startButton_Click(object sender, EventArgs e)
                {
                    StartTheQuiz();
                    startButton.Enabled = false;
                }

                public Form1()

                {
                    InitializeComponent();
                }

                private void label4_Click(object sender, EventArgs e)
                {

                }
            }
    }
}

    
