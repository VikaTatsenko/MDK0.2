﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Tours_Al
{
    internal class Manager
    {
        public static Frame MainFrame { get; set; }
    }
}
